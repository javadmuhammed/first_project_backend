
const emailConfig = {
    emailConfigObject: {
        host: "smtp.gmail.com",
        port: 587,
        service: 'gmail',
        auth: {
            user: 'javaddevelopment861@gmail.com',
            pass: 'fbvjqbozxenngram'
        }
    }
}


module.exports = emailConfig;